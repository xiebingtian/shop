<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// Route::get('user','user\Usercontroller@index');
// Route::get('user','user\Usercontroller@user');
// Route::get('user/{id}','user\Usercontroller@redi');
// Route::get('user/{id}',function($id){
// 	if($id>2){
// 		return redirect('http://www.baidu.com');
// 	}
// });
// Route::get('add','user\Usercontroller@add');
// Route::get('show','user\Usercontroller@show');
// Route::get('add','user\Usercontroller@add');
// Route::post('adddo','user\Usercontroller@adddo');
// Route::get('add','goods\GoodsController@add');
// Route::any('adddo','goods\GoodsController@adddo');
// Route::any('show','goods\GoodsController@show');
// Route::any('del','goods\GoodsController@del');
// Route::any('uphot','goods\GoodsController@uphot');
// Route::any('upsale','goods\GoodsController@upsale');
// Route::any('update','goods\GoodsController@update');
// Route::any('updatedo','goods\GoodsController@updatedo');
// Route::any('search','goods\GoodsController@search');
// Route::any('upname','goods\GoodsController@upname');
Route::get('index','shop\IndexController@index');
Route::get('register','shop\LoginController@register');
Route::get('userpage','shop\IndexController@userpage');
Route::get('login','shop\LoginController@login');
Route::post('registerdo','shop\LoginController@registerdo');
Route::post('logindo','shop\LoginController@logindo');
Route::post('send','shop\IndexController@send');
Route::get('demo','shop\IndexController@demo');
Route::post('ajaxupload','shop\IndexController@ajaxupload');
Route::get('allgoods','shop\GoodsController@allgoods');
Route::post('goodsshow','shop\GoodsController@goodsshow');
Route::get('shopcontent','shop\GoodsController@shopcontent');
Route::post('addgoods','shop\GoodsController@addgoods');
Route::get('shopcart','shop\GoodsController@shopcart');
Route::post('cart','shop\GoodsController@cart');
Route::post('updatenum','shop\GoodsController@updatenum');
Route::post('deletecart','shop\GoodsController@deletecart');
Route::get('payment','shop\OrderController@payment');
Route::post('ajaxpay','shop\OrderController@ajaxpay');
Route::get('address','shop\OrderController@address');
Route::post('check','shop\OrderController@check');
Route::get('writeaddr','shop\OrderController@writeaddr');
Route::post('addrdo','shop\OrderController@addrdo');
Route::post('updatedefault','shop\OrderController@updatedefault');
Route::post('del','shop\OrderController@del');
Route::get('updateaddress','shop\OrderController@updateaddress');
Route::post('update','shop\OrderController@update');
Route::get('buyrecord','shop\MineController@buyrecord');