<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<form action="adddo" method="post">
	<tr>
		用户名：<input type="text" name="name" >
	</tr><br>
	<tr>
		年龄：<input type="text" name="age" >
	</tr><br>
	<tr>
		<input type="submit" name="submit" value="submit">
	</tr>
	</form>
</body>
</html>