<?php

namespace App\Http\Controllers\goods;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\models\Goods;
use App\models\Category;
class GoodsController extends Controller
{
    public function add(){
    	$data=Category::all();
    	// dump($data);
    	return view('goods/add',['data'=>$data]);
    }
    public function adddo(Request $request){
    	$data=$request->input();
    	$res=Goods::insert($data);
    	// $res=DB::table('goods')->insert($data);
    	if($res==1){
    		return 1;
    	}
    }
    public function show(){
    	// $data=DB::table('goods')->paginate(1);
    	
    	$data=Goods::paginate(1);
    	
    	return view('goods/show',['data'=>$data]);
    }
    public function del(Request $request){
    	$id=$request->input('id');
    	// print_r($id);
    	// $res=DB::table('goods')->where('g_id',$id)->delete();
    	$res=Goods::where('g_id',$id)->delete();
    	if($res){
    		return 1;
    	}
    }

    public function search(Request $request){
		$is_sale=$request->input('is_sale');
    	$is_hot=$request->input('is_hot');
    	$where=[];
    	if(isset($is_sale)&&isset($is_hot)){
    		$where=['is_sale'=>$is_sale,'is_hot'=>$is_hot];
    	}else if(isset($is_sale)&&!isset($is_hot)){
			$where=['is_sale'=>$is_sale];
    	}else if(!isset($is_sale)&&isset($is_hot)){
			$where=['is_hot'=>$is_hot];
    	}
    	// print_r($where);
    	$data=Goods::where($where)->paginate(1);
    	return view('goods/show',['data'=>$data]);
    }

	public function update(Request $request){
		$id=$request->input('id');
		// dump($id);
		$data1=Category::all();
		$data=Goods::where('g_id',$id)->get();
		return view('goods/update',['data1'=>$data1,'data'=>$data]);
	} 

    public function updatedo(Request $request){
    	$data=$request->input();
    	$id=$data['g_id'];
    	// print_r($data);
    	$res=Goods::where('g_id',$id)->update($data);
    	print_r($res);
    }


    public function uphot(Request $request){
    	$is_hot=$request->input('is_hot');
    	// echo $is_hot;
    	$id=$request->input('id');
    	// echo $id;
    	if($is_hot=='是'){
    		$res=DB::table('goods')->where('g_id',$id)->update(['is_hot'=>1]);
    	}else if($is_hot=='否'){
    		$res=DB::table('goods')->where('g_id',$id)->update(['is_hot'=>0]);
    	}
    	if($res){
    		return 1;
    	}
    }

    public function upsale(Request $request){
    	$is_sale=$request->input('is_sale');
    	// echo $is_sale;
    	$id=$request->input('id');
    	// echo $id;
    	if($is_sale=='是'){
    		$res=DB::table('goods')->where('g_id',$id)->update(['is_sale'=>1]);
    	}else if($is_sale=='否'){
    		$res=DB::table('goods')->where('g_id',$id)->update(['is_sale'=>0]);
    	}
    	if($res){
    		return 1;
    	}
    }

    public function upname(Request $request){
    	$g_name=$request->input('str');
    	$g_id=$request->input('id');
    	$res=Goods::where('g_id',$g_id)->update(['g_name'=>$g_name]);
    	if($res){
    		return 1;
    	}
    }


    // public function nadd(){

    // }
}
