<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class Usercontroller extends Controller
{
	public function add(){
		return view('user/add');
	}
	public function adddo(Request $request){
		$name=$request->input('name');
		$age=$request->input('age');
		// dump($data);
		$sql="insert into user values(id,'$name',$age)";
		// echo $sql;exit;
		$res=DB::insert($sql);
	}
    // public function index(){
    // 	echo 11111;
    // }

    // public function user(Request $request){
    // 	$id=$request->input('id');
    // 	$name=$request->input('name');
    // 	echo $id;
    // 	echo $name;
    // 	// return view('user.user');

    // }
    // public function redi($id){
    // 	if($id>2){
    // 		return redirect('http://www.baidu.com');
    // 	}else{
    // 		echo 122313231;
    // 	}
    // }

    // public function add(){

    // 	$url=url('show');
    // 	// echo $a;
    // 	return redirect($url);
    // }

    // public function show(){
    // 	echo 123465;
    // }
}
