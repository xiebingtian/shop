<?php

namespace App\Http\Controllers\shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\User;
use App\models\Goods;
use App\models\Category;
use App\models\Cart;
use App\models\Order;
use App\models\Shop_order_detail;
use App\models\Address;
use Illuminate\Support\Facades\DB;
class OrderController extends Controller
{
    public function ajaxpay(Request $request){
    	$user_id=$request->session()->get('id');
    	$goods_id=$request->input('goods_id');
    	$price=$request->input('price');
    	if(!$user_id){
    		$arr=[
    			'status'=>0,
    			'msg'=>'请先登陆',
    		];
    		return $arr;
    	}
		$ndata=Goods::where('goods_up',0)->whereIn('goods_id',$goods_id)->get();
		    	$status=[];
		    	if($ndata){
		    		foreach($ndata as $val){
		    		$status[]=$val->goods_name;
		    		}
		    	if($status){
		    		$name=implode(',',$status);
		    		$arr=[
		    			'status'=>0,
		    			'msg'=>$name .'已下架'
		    		];
		    		return $arr;
		    	}
		    	}
    	
    	// $goods_id=$data['goods_id'];
    	$goodsdata=Goods::join('cart','goods.goods_id','=','cart.goods_id')->whereIn('goods.goods_id',$goods_id)->where('status',0)->get();
    	$data=[];
    	foreach($goodsdata as $val){
    		if($val->buy_num>$val->goods_num){
    			$data[]=$val->goods_name;
    		}
    	}
    	if($data){
    		$name=implode(',',$data);
    		$arr=[
    			'status'=>0,
    			'msg'=>$name .'库存不足'
    		];
    		return $arr;
    	}
    	$time=date('YmdHis',time());
    	
    	$sn='sn'.$time.rand(11111,99999);
    	$newdata=[
    		'order_sn'=>$sn,
    		'u_id'=>$user_id,
    		'order_amount'=>$price,
    	];
    	$order_id=Order::insertGetId($newdata);
    	// $obj=Order::where('goods_id')
    	// $order
    	if($order_id){
	    		foreach($goodsdata as $v){
	    		$newdata1=[
	    			'goods_id'=>$v->goods_id,
	    			'user_id'=>$user_id,
	    			'goods_name'=>$v->goods_name,
	    			'buy_number'=>$v->buy_num,
	    			'goods_price'=>$v->goods_selfprice,
	    			'goods_img'=>$v->goods_img,
	    			'status'=>1,
	    			'order_id'=>$order_id,
	    			'order_sn'=>$sn,
	    		];
	    		$res=Shop_order_detail::insert($newdata1);
	    	}
    	}
    	
    	
    	$res1=Cart::whereIn('goods_id',$goods_id)->where('user_id',$user_id)->update(['status'=>1]);
    	if($res){
    		$arr=[
    			'status'=>1,
    		];
    		return $arr;
    	}


    }

    public function payment(Request $request){
    	$goods_id=$request->input('goods_id');
    	$price=$request->input('price');
    	$goods_id=explode(',',$goods_id);
    	// print_r($goods_id);echo $price;
    	$goodsdata=Goods::join('cart','goods.goods_id','=','cart.goods_id')->whereIn('goods.goods_id',$goods_id)->get();
    	// print_r($goodsdata);exit;
    	return view('order.payment',['goodsdata'=>$goodsdata,'price'=>$price]);
    }


    public function check(Request $request){
    	$uid=$request->session()->get('id');
    	$res=Address::where('user_id',$uid)->first();
    	// print_r($res);exit;
    	if(empty($res)){
    		$arr=[
    			'status'=>0,
    			'msg'=>'请先添加收货地址'
    		];
    		return $arr;
    	}else{
    		$arr=[
    			'status'=>1,
    		];
    		return $arr;
    	}
    }

    public function address(Request $request){
    	$uid=$request->session()->get('id');
    	$data=Address::where('user_id',$uid)->where('is_show',0)->get();
    	return view('order.address',['data'=>$data]);
    }

    public function writeaddr(){
    	return view('order.writeaddr');
    }

    public function addrdo(Request $request){
    	$data=$request->input();
    	$uid=$request->session()->get('id');
    	if(empty($data['is_default'])){
    		$data['is_default']=0;
    	}
    	$data['user_id']=$uid;
    	Address::where('user_id',$uid)->update(['is_default'=>0]);
    	$res=Address::insert($data);
    	if($res){
    		$arr=[
    			'status'=>1,
    			'msg'=>'添加成功',
    		];
    		return $arr;
    	}
    }


    public function updatedefault(Request $request){
    	$uid=$request->session()->get('id');
    	$address_id=$request->input('address_id');
    	Address::where('user_id',$uid)->update(['is_default'=>0]);
    	$res=Address::where('address_id',$address_id)->update(['is_default'=>1]);
    	if($res){
    		$arr=[
    			'status'=>1,
    			'msg'=>'修改成功',
    		];
    		return $arr;
    	}
    }

    public function del(Request $request){
    	// return 1;
    	$address_id=$request->input('address_id');
    	$res=Address::where('address_id',$address_id)->update(['is_show'=>1]);
    	if($res){
    		$arr=[
    			'status'=>1,
    			'msg'=>'删除成功'
    		];
    		return $arr;
    	}
    }

    public function updateaddress(Request $request){
    	$address_id=$request->input('address_id');
    	// echo $address_id;
    	// DB::enableQueryLog();
    	$data=Address::where('address_id',$address_id)->first();
    	// dd(\DB::getQueryLog());
    	// print_r($data->consignee);exit;
    	return view('order.updateaddress',['data'=>$data]);
    }

    public function update(Request $request){
    	$data=$request->input();
    	// print_r($data);exit();
    	$address_id=$data['address_id'];
    	$uid=$request->session()->get('id');
    	if(empty($data['is_default'])){
    		$data['is_default']=0;
    	}
    	$data['user_id']=$uid;
    	Address::where('user_id',$uid)->update(['is_default'=>0]);
    	$res=Address::where('address_id',$address_id)->update($data);
    	if($res){
    		$arr=[
    			'status'=>1,
    			'msg'=>'修改成功',
    		];
    		return $arr;
    	}
    }

}
