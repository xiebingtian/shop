<?php

namespace App\Http\Controllers\shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\User;
use App\models\Goods;
use App\models\Code;
class LoginController extends Controller
{
    public function login(){
    	return view('login.login');
    }

    public function logindo(Request $request){
    	$data=$request->input();
    	$where=['tel'=>$data['tel'],'pwd'=>md5($data['pwd'])];
    	$res=User::where($where)->get()->toArray();
    	if(!empty($res)){
    		session(['id'=>$res[0]['user_id'],'tel'=>$res[0]['tel']]);
    		$arr=['status'=>1,'msg'=>'登陆成功'];
    	}else{
    		$arr=['status'=>0,'msg'=>'登陆失败'];
    	}
    	return $arr;
    }

       public function register(){
    	return view('login.register');
    }

    public function registerdo(Request $request){
    	$data=$request->input();
    		$newdata=[];
    		$newdata['tel']=$data['tel'];
    		$newdata['pwd']=md5($data['pwd']);
    		if(isset($data['pwd'])&&isset($data['tel'])){
				if($data['pwd']!=$data['conpwd']){
						$arr=[
						'status'=>0,
						'msg'=>'两次密码不一致',
						];
				}else{
						$ndata=User::where('tel',$newdata['tel'])->get()->toArray();
						if(empty($ndata)){
						$obj=Code::where('tel',$data['tel'])->where('code',$data['code'])->where('status',1)->get()->count();
						if(!$obj){
						$arr=[
						'status'=>0,
						'msg'=>'验证码错误',
						];
						}else{
							$res=User::insert($newdata);
							if($res){
							$arr=[
							'status'=>1,
							'msg'=>'注册成功',
							];
							}else{
								$arr=[
								'status'=>0,
								'msg'=>'注册失败',
								];
							}
							}
						
					}else{
						$arr=[
						'status'=>0,
						'msg'=>'此手机号已注册',
						];
						}
						}
				
    		}else{
    			$arr=[
    				'status'=>0,
    				'msg'=>'手机号和密码不能为空'
    			];
    		}
    		return $arr;
    	
    }
}
