<?php

namespace App\Http\Controllers\shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\Order;
use App\models\Shop_order_detail;
class MineController extends Controller
{
	public function buyrecord(Request $request){
		$uid=$request->session()->get('id');
		$orderdetaildata=Shop_order_detail::where('user_id',$uid)->get();
		return view('mine.buyrecord',['orderdetaildata'=>$orderdetaildata]);
	}
    
}
