<?php

namespace App\Http\Controllers\shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\User;
use App\models\Goods;
use App\models\Category;
use App\models\Cart;
use App\models\Order;
use App\models\Shop_order_detail;
use Illuminate\Support\Facades\DB;
class GoodsController extends Controller
{
    public function allgoods(){
    	$catedata=Category::where('pid',0)->get(['cate_id','cate_name']);
    	$goodsdata=Goods::join('category','goods.cate_id','=','category.cate_id')->orderBy('goods_score','desc')->get(['goods_id','cate_name','goods_name','goods_id','goods_selfprice','goods_img','goods_score']);
    	return view('goods/allgoods',['catedata'=>$catedata,'goodsdata'=>$goodsdata]);
    }

    public function goodsshow(Request $request){
    	$cate_id=$request->input('cate_id');
    	$catedata=category::all();
    	$ndata=$this->createtree($catedata,$cate_id);
    	array_unshift($ndata,$cate_id);
    	// print_r($ndata) ;die;
    	$ngoodsdata=Goods::whereIn('cate_id',$ndata)->orderBy('goods_score','desc')->get();
    	$content=response(view('goods/goodsshow',['ngoodsdata'=>$ngoodsdata]))->getcontent();
    	$arr['info']=$content;
    	return $arr;
    }

   

	public function createtree($data=[],$cate_id=0){
	        static $arr=[];
	        foreach($data as $k=>$v){
	            if($v['pid']==$cate_id){
	                $arr[]=$v['cate_id'];
	                $this->createtree($data,$v['cate_id']);
	            }
	        }
	        return $arr;
	    }


    public function shopcontent(Request $request){
    		$goods_id=$request->input('goods_id');
    		$goodsdata=Goods::where('goods_id',$goods_id)->first();
    		// print_r($goodsdata);
    		$num=Cart::all();
			if(!empty($num)){
			$num=Cart::where('status',0)->get()->toArray();
			}else{
			$num=Cart::where('status',0)->get();	
			}
			$num=array_column($num,'buy_num');
			$num=array_sum($num);
    		return view('goods/shopcontent',['goodsdata'=>$goodsdata,'num'=>$num]);
    }


    public function addgoods(Request $request){
    		$goods_id=$request->input('goods_id');

    		if(empty($request->session()->get('id'))){
	    			$arr=[
	    				'msg'=>'请先登陆',
	    				'status'=>'2'
	    			];
	    			return $arr;
    		}else{
    			$data=Goods::where('goods_id',$goods_id)->where('goods_up',1)->where('goods_num','>',0)->first();
    			if(empty($data)){
					$arr=[
	    				'msg'=>'库存不足',
	    				'status'=>'0'
	    			];
    			return $arr;
    			}else{
    				$cartdata=Cart::where('goods_id',$goods_id)->first();
    				if(!empty($cartdata)){
    					$res=Cart::where('cart_id',$cartdata->cart_id)->update(['buy_num'=>$cartdata->buy_num+1]);
    					if($res){
	    						$arr=[
		    						'msg'=>'添加成功',
		    						'status'=>'1',
		    						// 'num'=>$num
		    					];
		    					// Goods::where('goods_id',$goods_id)->update(['goods_num'=>$data->goods_num-1]);
	    					return $arr;
    					}
    				}else{
    					$user_id=$request->session()->get('id');
    					$time=time();
    					$ndata=[
    						'goods_id'=>$goods_id,
    						'buy_num'=>1,
    						'add_time'=>$time,
    						'user_id'=>$user_id,
    					];
    					$res=Cart::insert($ndata);
	    					if($res){
	    						$arr=[
		    						'msg'=>'添加成功',
		    						'status'=>'1'
		    					];
		    					// Goods::where('goods_id',$goods_id)->update(['goods_num'=>$data->goods_num-1]);
	    					return $arr;
    					}
    				}
    			}
    		}
    }

    public function shopcart(Request $request){
    	if(empty($request->session()->get('id'))){
	    			return redirect('login');
    		}
    	$user_id=$request->session()->get('id');
    	// DB::enableQueryLog();

    	$goodsdata=Goods::join('cart','goods.goods_id','=','cart.goods_id')->where('user_id',$user_id)->where('status',0)->get();
    	// dd(\DB::getQueryLog());exit;
    	// print_r($goodsdata);exit;
    	$ndata=Goods::where('goods_best',1)->orderBy('create_time','desc')->limit(4)->select()->get();
    	// dump($ndata);
    	return view('goods.shopcart',['goodsdata'=>$goodsdata,'ndata'=>$ndata]);
    }

    public function cart(Request $request){
    	if(empty($request->session()->get('id'))){
	    			$arr=[
	    				'msg'=>'请先登陆',
	    				'status'=>'1'
	    			];
	    			return $arr;
    		}else{
    			$arr=[
	    				'status'=>'0'
	    			];
	    			return $arr;
    		}
    }



    public function updatenum(Request $request){
    	$cart_id=$request->input('cart_id');
    	$buy_num=$request->input('buy_num');
    	$goods_id=Cart::where('cart_id',$cart_id)->first()->goods_id;
    	$goods_num=Goods::where('goods_id',$goods_id)->first()->goods_num;
    	// print_r($buy_num);exit;
    	if($buy_num>$goods_num){
    		Cart::where('cart_id',$cart_id)->update(['buy_num'=>$goods_num]);
    		$arr=[
    			'msg'=>'库存不足',
    			'status'=>0,
    		];
    		return $arr;
    	}
    	if($buy_num<1){
    		Cart::where('cart_id',$cart_id)->update(['buy_num'=>1]);
    		$arr=[
    			'msg'=>'购买数量不可小于1',
    			'status'=>0,
    		];
    		return $arr;
    	}
    	Cart::where('cart_id',$cart_id)->update(['buy_num'=>$buy_num]);
    }


    public function deletecart(Request $request){
    	$cart_id=$request->input('cart_id');
    	// print_r($cart_id);exit;
    	$res=Cart::whereIn('cart_id',$cart_id)->update(['status'=>1]);
    	if($res){
    		$arr=[
    			'status'=>0,
    		];
    		return $arr;
    	}
    }


    

    
}

