<?php

namespace App\Http\Controllers\shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\User;
use App\models\Goods;
use App\models\Code;
class IndexController extends Controller
{
    public function index(){
    	$data=Goods::where('goods_best',1)->orderby('goods_id','desc')->limit(2)->get(['goods_name','goods_img','goods_id']);
    	return view('index.index',['data'=>$data]);
    }

 

    public function userpage(Request $request){
    	$res=$request->session()->get('tel');
    	return view('index.userpage',['res'=>$res]);
    }

    

    public function send(Request $request){
    	$tel=$request->input('tel');
    	$num = rand(1000,9999);
    	$time=time()+60;
    	// $obj=new \send();
    	// $str=$obj->show($tel,$num);
    	$str=108;
    	if($str==108){
    		$data=[
    		'code'=>$num,
    		'status'=>1,
    		'tel'=>$tel,
    		'outtime'=>$time
    	];
    	$res=Code::insert($data);
    	}
    }


    public function demo(){
    	return view('demo');
    }


    public function ajaxupload(Request $request){
    	$page=$request->input('page',1);
    	$pagenum=8;
    	$offset=($page-1).$page;
    	$data=Goods::offset($offset)->limit($pagenum)->where('goods_hot',1)->get(['goods_id','goods_name','goods_img','goods_selfprice']);
    	$count=Goods::where('goods_hot',1)->count();
    	$totalpage=ceil($count/$pagenum);
    	$content=response(view('index/ajaxupload',['data'=>$data]))->getcontent();
    	$arr['info']=$content;
    	$arr['page']=$totalpage;
    	return $arr;
    }

    
}
