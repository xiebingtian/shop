<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Shop_order_detail extends Model
{
    protected $table='shop_order_detail';
}
